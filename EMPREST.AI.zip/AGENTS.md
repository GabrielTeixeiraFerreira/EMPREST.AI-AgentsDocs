# Instruções do projeto

## Escopo

- `EMPREST.AI/` contém o frontend.
- `EMPREST.AI-Back/` contém o backend.
- Antes de investigar ou alterar arquivos, pergunte ao usuário se o escopo é frontend ou backend.

## Processo de trabalho

- Explique o plano antes de fazer alterações.
- Responda em português.
- Não crie commits nem pull requests; deixe essas ações para o usuário.
- Ao concluir uma alteração, execute os testes como verificação obrigatória.
- Se os testes falharem, pare, analise o problema e explique a causa e o impacto. Só faça ajustes depois que o usuário aceitar.
- Quando a tarefa afetar a verificação final, siga o checklist de `rules/check.md`.
- Quando a tarefa afetar schema ou migration, siga o procedimento de `rules/migration.md`.
- Para mudanças de produto ou código, siga o fluxo SDD definido em `rules/spec-flow.md`.
- Para salvar o estado de uma sessão, siga a regra de handoff definida em `rules/handoff.md`.
- Para criar ou alterar código, siga a matriz de testes definida em `rules/testing.md`.

## Arquitetura e código

- Use Arquitetura Limpa.
- Siga os princípios SOLID.

## Referências do projeto

- Consulte `EMPREST.AI/docs/PRD.md` para os requisitos do produto.
- Consulte `EMPREST.AI/docs/adr/001-stack.md` para as decisões de arquitetura, stack, testes, operação e segurança.
- Consulte `rules/check.md` para o processo de verificação antes de afirmar que a tarefa está pronta.
- Consulte `rules/migration.md` para qualquer mudança de schema ou migration.
- Consulte `rules/spec-flow.md` para criar spec, plano e tasks antes de implementar.
- Consulte `rules/handoff.md` para salvar uma sessão em `docs/handoff/` quando o usuário pedir.
- Consulte `rules/testing.md` para escolher e executar os testes conforme a ADR.
- No backend, preserve a organização por domínio e as camadas `Controller -> Service -> Repository` definidas no ADR.
- Consulte `skills/` para verificar as skills adicionais do projeto
